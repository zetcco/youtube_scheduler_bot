# Youtube Updater Bot

This bot schedules youtube videos.

DISCLAIMER : THIS WORKS ONLY ON NEW YOUTUBE STUDIO

How to run      : 1. Close any chrome windows that are running.
                  2. Run the python file on data/ytidman.py
